# Molecular Mode App
A ritual-based molecular spinner powered by React and Framer Motion.